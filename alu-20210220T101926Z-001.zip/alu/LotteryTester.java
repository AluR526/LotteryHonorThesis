package alu;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * HonorsThesis
 * @author Ryan Alu, Saint Francis University
 * Jun 21, 2019
 */

public class LotteryTester
{
    public static void main(String[] args) throws FileNotFoundException, IOException
    {
        Lottery execute = new Lottery();
        execute.runTest(execute.loadFiles());
    }
}   
