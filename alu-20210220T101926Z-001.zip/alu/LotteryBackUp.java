package alu;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 * HonorsThesis
 * @author Ryan Alu, Saint Francis University
 * May 13, 2019
 */

public class LotteryBackUp
{
    public LotteryBackUp()
    {
        
    }
    
    public ArrayList<ArrayList<ArrayList<String>>> loadFiles() throws FileNotFoundException, IOException
    {
        
        ArrayList<String> fileLocationList = new ArrayList<>();
        File folder = new File("C:\\Users\\SFU\\Desktop\\LotteryThesis\\LotteryUSAConvert");
        File[] listOfFiles = folder.listFiles();

        ArrayList<ArrayList<ArrayList<String>>> master = new ArrayList<>();
        master.add(new ArrayList<>());
        master.get(0).add(new ArrayList<>());
        master.get(0).get(0).add("MASTER");
        //Master
            //Lotto
                //Date [0]
                //Numbers [1...]
                        
        for(int i=0; i<listOfFiles.length; i++)
        {
            int lineCounter = 0;
            String date = "";
            String numberSet = "";
            if (listOfFiles[i].isFile())
            {
                master.add(new ArrayList<>());
                master.get(i+1).add(new ArrayList<>());
                master.get(i+1).get(0).add(listOfFiles[i].getName());
                
                BufferedReader br = new BufferedReader(new FileReader(listOfFiles[i]));
                String st = br.readLine();
                st = br.readLine();
                
                while(st != null)
                {
                    for(int j=0; j<st.length(); j++)
                    {
                        if(st.substring(j,j+1).equals(","))
                        {
                            date = st.substring(0,j);
                            numberSet = st.substring(j+1,st.length());
                            
                            if(numberSet.contains(","))
                            {
                                master.get(i+1).add(new ArrayList<>());
                                master.get(i+1).get(lineCounter+1).add("*" + date);
                            }
                            else
                            {
                                master.get(i+1).add(new ArrayList<>());
                                master.get(i+1).get(lineCounter+1).add(date);
                            }

                            for(int k=0; k<numberSet.length(); k+=3)
                            {
                                master.get(i+1).get(lineCounter+1).add(numberSet.substring(k,k+2));
                            }
                            break;
                        }
                    }
                    lineCounter++;
                    st = br.readLine();
                }
            }
        }
        //System.out.println(master);
        return master;
    }
    
    public ArrayList<ArrayList<Double>> runTest(ArrayList<ArrayList<ArrayList<String>>> master2)
    {
        ArrayList<ArrayList<Double>> zScoreArray = new ArrayList<>();
        
        for(int i=1; i<master2.size(); i++)
        {
            zScoreArray.add(new ArrayList<>());
            String yesNumber = master2.get(i).get(0).get(0).substring(master2.get(i).get(0).get(0).indexOf("-")+1, master2.get(i).get(0).get(0).indexOf("-")+3);
            
            for(int q=Integer.parseInt(yesNumber); q>0; q--)
            {
                int yesNumberCounter = 0;
                int noNumberCounter = 0;

                String spot1 = "";
                String spot2 = "";
                int runCounter = 0;

                double mG = 0.0;
                double sigmaG = 0.0;

                double z = 0.0;
                
                for(int j=1; j<master2.get(i).size(); j++)
                {
                    int bonusBallSubtractor = 0;
                    if(master2.get(i).get(j).get(0).contains("*"))
                    {
                        bonusBallSubtractor = 1;
                    }
                    for(int k=1; k<master2.get(i).get(j).size()-bonusBallSubtractor; k++)
                    {
                        //Count Amount
                        if(master2.get(i).get(j).get(k).equals(yesNumber))
                        {
                            yesNumberCounter++;
                        }
                        else
                        {
                            noNumberCounter++;
                        }
                        
                        //Count runs
                        spot2 = master2.get(i).get(j).get(k);
                        if(spot2.equals(spot1))
                        {
                            runCounter++;
                        }
                        spot1 = spot2;
                    }
                }

                mG = (((2*yesNumberCounter*noNumberCounter)/(yesNumberCounter + noNumberCounter))+1);
                sigmaG = Math.sqrt(((2*yesNumberCounter*noNumberCounter) * ((2*yesNumberCounter*noNumberCounter) - yesNumberCounter - noNumberCounter))  /  (((yesNumberCounter + noNumberCounter) * (yesNumberCounter + noNumberCounter)) * ((yesNumberCounter + noNumberCounter)-1)));
                
                z = ((runCounter - mG)/sigmaG);
                
                //zScore of highest number that can be drawn will be at 0
                zScoreArray.get(i-1).add(z);
                //Decrease Yes Number
                yesNumber = ("" + (Integer.parseInt(yesNumber)-1));
            }
            //TESTING SO REMOVE THIS WHEN DONE TESTING;
            break;
        }
        return zScoreArray;
    }
    
    public void statRandomAnswer(ArrayList<ArrayList<Double>> zScoreArray2)
    {
        for(int i=0; i<zScoreArray2.size(); i++)
        {
            for(int j=0; j<zScoreArray2.get(i).size(); j++)
            {
                if(zScoreArray2.get(i).get(j)<-1.96 || zScoreArray2.get(i).get(j)>1.96)
                {
                    System.out.println(i);
                    System.out.println(j);
                    System.out.println(zScoreArray2.get(i).get(j));
                    System.out.println("REJECT!");
                    System.out.println();
                    break;
                }
            }
        }
    }
}   
