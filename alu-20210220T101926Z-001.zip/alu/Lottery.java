package alu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * HonorsThesis
 * @author Ryan Alu, Saint Francis University
 * May 13, 2019
 */

public class Lottery
{
    public Lottery()
    {
        
    }
    
    public ArrayList<ArrayList<ArrayList<String>>> loadFiles() throws FileNotFoundException, IOException
    {
        
        ArrayList<String> fileLocationList = new ArrayList<>();
        File folder = new File("C:\\Users\\SFU\\Desktop\\LotteryThesis\\LotteryUSAConvert");
        File[] listOfFiles = folder.listFiles();

        ArrayList<ArrayList<ArrayList<String>>> master = new ArrayList<>();
        master.add(new ArrayList<>());
        master.get(0).add(new ArrayList<>());
        master.get(0).get(0).add("MASTER");
        //Master
            //Lotto
                //Date [0]
                //Numbers [1...]
                        
        for(int i=0; i<listOfFiles.length; i++)
        {
            int lineCounter = 0;
            String date = "";
            String numberSet = "";
            if (listOfFiles[i].isFile())
            {
                master.add(new ArrayList<>());
                master.get(i+1).add(new ArrayList<>());
                master.get(i+1).get(0).add(listOfFiles[i].getName());
                
                BufferedReader br = new BufferedReader(new FileReader(listOfFiles[i]));
                String st = br.readLine();
                st = br.readLine();
                
                while(st != null)
                {
                    for(int j=0; j<st.length(); j++)
                    {
                        if(st.substring(j,j+1).equals(","))
                        {
                            date = st.substring(0,j);
                            numberSet = st.substring(j+1,st.length());
                            
                            if(numberSet.contains(","))
                            {
                                master.get(i+1).add(new ArrayList<>());
                                master.get(i+1).get(lineCounter+1).add("*" + date);
                            }
                            else
                            {
                                master.get(i+1).add(new ArrayList<>());
                                master.get(i+1).get(lineCounter+1).add(date);
                            }

                            for(int k=0; k<numberSet.length(); k+=3)
                            {
                                master.get(i+1).get(lineCounter+1).add(numberSet.substring(k,k+2));
                            }
                            break;
                        }
                    }
                    lineCounter++;
                    st = br.readLine();
                }
            }
        }
        return master;
    }
    
    public void runTest(ArrayList<ArrayList<ArrayList<String>>> master2)
    {
        ArrayList<Double> zScoreArrayLine = new ArrayList<>();
        ArrayList<ArrayList<Double>> zScoreArrayPosition = new ArrayList<>();
        ArrayList<Double> zScoreArrayGroup = new ArrayList<>();
        
        //Go through each lottery
        for(int i=1; i<master2.size(); i++)
        {
            //LINE
            //Look at file names. We are getting the maximum number a ball can have on it.
            String n = master2.get(i).get(0).get(0).substring(master2.get(i).get(0).get(0).indexOf("-")+1, master2.get(i).get(0).get(0).indexOf("-")+3);
            //Created array for counting how many times each number appears
            int njCounterArray[] = new int[Integer.parseInt(n) + 1];
            //Making slot 0 nothing so the lottery numbers will line up with slot location. When you see a 1 count it in slot 1 as opposed to slot 0.
            njCounterArray[0] = 99999;
            //Setting up for run counting
            String spot1L = "";
            String spot2L = "";
            int runCounterL = 1;
            
            //POSITION
            //Look at file names. We are getting the maximum number of slots (How many balls are drawn)
            String rcp="";
            if(master2.get(i).get(0).get(0).substring(master2.get(i).get(0).get(0).indexOf("-")-2, master2.get(i).get(0).get(0).indexOf("-")-1).equals("_"))
            {
                rcp = master2.get(i).get(0).get(0).substring(master2.get(i).get(0).get(0).indexOf("-")-1, master2.get(i).get(0).get(0).indexOf("-"));
            }
            else
            {
                rcp = master2.get(i).get(0).get(0).substring(master2.get(i).get(0).get(0).indexOf("-")-2, master2.get(i).get(0).get(0).indexOf("-"));
            }
            //Created array for counting how many times each number appears for each slot
            ArrayList<Integer> runCounterP = new ArrayList<>();
            //To line things up. If there are 5 numbers we are iterating 1-5 because slot 0 is the date
            runCounterP.add(99999);
            for(int y=0; y<Integer.parseInt(rcp); y++)
            {
                runCounterP.add(1);
            }
            int runCounterG = 0;
            
            //GROUP
            recursion(master2.get(i).get(1), 1, 0, master2.get(i), i);
            return;
            
            //I put bonus ball indicator on each date for some reason. So it checks the date of each draw and sees if it has a star on it. If so, don't count the last (bonus ball) number.
            for(int j=1; j<master2.get(i).size(); j++)
            {
                int bonusBallSubtractor = 0;
                if(master2.get(i).get(j).get(0).contains("*"))
                {
                    bonusBallSubtractor = 1;
                }
                for(int k=1; k<master2.get(i).get(j).size()-bonusBallSubtractor; k++)
                {
                    //Count Amount
                    njCounterArray[Integer.parseInt(master2.get(i).get(j).get(k))]++;
                    
                    //Count runs Line
                    spot2L = master2.get(i).get(j).get(k);
                    if(!spot2L.equals(spot1L))
                    {
                        runCounterL++;
                    }
                    spot1L = spot2L;
                    
                    //Count runs Position
                    if(j!=1 && !master2.get(i).get(j).get(k).equals(master2.get(i).get(j-1).get(k)))
                    {
                        runCounterP.set(k, runCounterP.get(k)+1);
                    }
                    
                }
            }
            
            //Obtaining mG
            double mGp1 = Double.parseDouble(n)*(Double.parseDouble(n)+1);
            double mGsum = 0.0;
            for(int q=1; q<njCounterArray.length; q++)
            {
                mGsum =+ Math.pow(njCounterArray[q],2);
            }
            double mG = (mGp1 - mGsum)/Double.parseDouble(n);
            
            //Obtaining sigmaG
            double sigmaGp1 = mGsum*(mGsum + mGp1);
            double sigmaGsum = 0.0;
            for(int q=1; q<njCounterArray.length; q++)
            {
                sigmaGsum =+ Math.pow(njCounterArray[q],2);
            }
            double sigmaGp2 = 2*Double.parseDouble(n)*sigmaGsum;
            double sigmaGp3 = Math.pow(Double.parseDouble(n),3);
            double sigmaGp4 = Math.pow(Double.parseDouble(n),2)*(Double.parseDouble(n)-1);
            double sigmaG = (sigmaGp1 - sigmaGp2 - sigmaGp3)/sigmaGp4;
            
            //First lotto lines up with slot 0
            if(runCounterL>=mG)
            {
                zScoreArrayLine.add((runCounterL - mG - .5)/sigmaG);
                
            }
            else
            {
                zScoreArrayLine.add((runCounterL - mG + .5)/sigmaG);
            }
            
            zScoreArrayPosition.add(new ArrayList<>());
            for(int p=1; p<runCounterP.size(); p++)
            {
                
                //zScoreArray Position is an Array in an Array. Get to the latest addition (latest lottery). Add each slot's z score.
                if(runCounterP.get(p)>=mG)
                {
                    zScoreArrayPosition.get(zScoreArrayPosition.size()-1).add((runCounterP.get(p)- mG - .5)/sigmaG);
                }
                else
                {
                    zScoreArrayPosition.get(zScoreArrayPosition.size()-1).add((runCounterP.get(p)- mG + .5)/sigmaG);
                }    
            }
        }
        statRandomAnswer(zScoreArrayLine, zScoreArrayPosition);
    }
    
    private void statRandomAnswer(ArrayList<Double> zScoreArrayLine2, ArrayList<ArrayList<Double>> zScoreArrayPosition2)
    {
        System.out.println("-----------------------------------------------------------------------------------");
        System.out.println("zScoreArrayLine");
        System.out.println();
        for(int i=0; i<zScoreArrayLine2.size(); i++)
        {
            if(zScoreArrayLine2.get(i)<-1.96 || zScoreArrayLine2.get(i)>1.96)
            {
                System.out.println("REJECT!");
                System.out.println(i);
                System.out.println(zScoreArrayLine2.get(i));
                System.out.println();
            }
        }
        System.out.println("-----------------------------------------------------------------------------------");
        
        System.out.println();
        
        System.out.println("-----------------------------------------------------------------------------------");
        System.out.println("zScoreArrayPosition");
        System.out.println();
        for(int i=0; i<zScoreArrayPosition2.size(); i++)
        {
            for(int j=0; j<zScoreArrayPosition2.get(i).size(); j++)
            {
                if(zScoreArrayPosition2.get(i).get(j)<-1.96 || zScoreArrayPosition2.get(i).get(j)>1.96)
                {
                    System.out.println("REJECT!");
                    System.out.println(i);
                    System.out.println(j);
                    System.out.println(zScoreArrayPosition2.get(i).get(j));
                    System.out.println();
                }
            }
        }
    }
    
    //A sad attempt at recursion that does not work and is sad . . . 3 is the amount of numbers selected
    private void recursion(ArrayList<String> a, int level, int iterator, ArrayList<ArrayList<String>> og, int lottoNum)
    {
        System.out.print(a.get(iterator / (int)Math.pow(a.size(), (2 - level)) % a.size()));
        if(level == og.get(lottoNum).size())
        {
            System.out.println();
            level=0;
            iterator++;
        }
        if(iterator == 81)
        {
            return;
        }
        recursion(og.get(level + 1), level + 1, iterator, og, lottoNum);
    }
}   
//recursion(master2.get(i).get(1), 1, 0, master2.get(i));